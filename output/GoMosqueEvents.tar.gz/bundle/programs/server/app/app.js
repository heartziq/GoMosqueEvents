var require = meteorInstall({"imports":{"api":{"events.js":["meteor/meteor","meteor/mongo","meteor/check",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////
//                                                                                   //
// imports/api/events.js                                                             //
//                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////
                                                                                     //
exports.__esModule = true;                                                           //
exports.Events = undefined;                                                          //
                                                                                     //
var _meteor = require('meteor/meteor');                                              // 1
                                                                                     //
var _mongo = require('meteor/mongo');                                                // 2
                                                                                     //
var _check = require('meteor/check');                                                // 3
                                                                                     //
// initialise a collection here. mongo collection name should be the file name.      //
var Events = exports.Events = new _mongo.Mongo.Collection('events');                 // 6
                                                                                     //
if (_meteor.Meteor.isServer) {                                                       // 8
  //declare all publish relating to the collection here                              //
  //EXAMPLE:                                                                         //
  _meteor.Meteor.publish('allEvents', function () {                                  // 11
    function eventsPublication() {                                                   // 11
      return Events.find();                                                          // 12
    }                                                                                //
                                                                                     //
    return eventsPublication;                                                        //
  }());                                                                              //
                                                                                     //
  _meteor.Meteor.publish("allUsers", function () {                                   // 15
    return _meteor.Meteor.users.find({});                                            // 16
  });                                                                                //
}                                                                                    //
                                                                                     //
_meteor.Meteor.methods({                                                             // 21
  //declare all methods related to the collection here                               //
  // EXAMPLE:                                                                        //
  addEvents: function () {                                                           // 24
    function addEvents(name, description, theDate, start, end, needParticipants, numberParticipants, needVolunteers, numberVolunteers, gender) {
      if (!name || !description || !theDate || !start || !end || !needParticipants || !numberParticipants || !needVolunteers || !numberVolunteers || !gender) {
        throw new _meteor.Meteor.Error('Some input fields are not filled in.');      // 27
      }                                                                              //
      // Make sure the user is logged in before inserting a task                     //
      if (!this.userId) {                                                            // 25
        throw new _meteor.Meteor.Error('not-authorized');                            // 31
      }                                                                              //
                                                                                     //
      Events.insert({                                                                // 34
        name: name,                                                                  // 35
        description: description,                                                    // 36
        theDate: theDate,                                                            // 37
        start: start,                                                                // 38
        end: end,                                                                    // 39
        needParticipants: needParticipants,                                          // 40
        numberParticipants: numberParticipants,                                      // 41
        needVolunteers: needVolunteers,                                              // 42
        numberVolunteers: numberVolunteers,                                          // 43
        gender: gender,                                                              // 44
        createdAt: new Date(), // current time                                       // 45
        mosqueId: _meteor.Meteor.userId(), // _id of logged in user                  // 46
        mosqueName: _meteor.Meteor.user().profile.name // username of logged in user
      });                                                                            // 34
    }                                                                                //
                                                                                     //
    return addEvents;                                                                //
  }(),                                                                               //
  updateEvents: function () {                                                        // 50
    function updateEvents(eventId, name, description, theDate, start, end, needParticipants, numberParticipants, needVolunteers, numberVolunteers, gender) {
      if (!name || !description || !theDate || !start || !end || !needParticipants || !numberParticipants || !needVolunteers || !numberVolunteers || !gender) {
        throw new _meteor.Meteor.Error('Some input fields are not filled in.');      // 53
      }                                                                              //
      // Make sure the user is logged in before inserting a task                     //
      if (!this.userId) {                                                            // 51
        throw new _meteor.Meteor.Error('not-authorized');                            // 57
      }                                                                              //
                                                                                     //
      Events.update({ _id: eventId }, {                                              // 60
        $set: {                                                                      // 61
          name: name,                                                                // 62
          description: description,                                                  // 63
          theDate: theDate,                                                          // 64
          start: start,                                                              // 65
          end: end,                                                                  // 66
          needParticipants: needParticipants,                                        // 67
          numberParticipants: numberParticipants,                                    // 68
          needVolunteers: needVolunteers,                                            // 69
          numberVolunteers: numberVolunteers,                                        // 70
          gender: gender,                                                            // 71
          updatedAt: new Date() }                                                    // 72
      });                                                                            //
    }                                                                                //
                                                                                     //
    return updateEvents;                                                             //
  }(),                                                                               //
  // current time                                                                    //
  participateUser: function () {                                                     // 77
    function participateUser(eventId) {                                              //
      Events.update({ _id: eventId }, {                                              // 78
        $addToSet: {                                                                 // 79
          participants: _meteor.Meteor.user().emails[0].address                      // 80
        } });                                                                        //
    }                                                                                //
                                                                                     //
    return participateUser;                                                          //
  }(),                                                                               //
  cancelParticipation: function () {                                                 // 83
    function cancelParticipation(eventId) {                                          //
      Events.update({ _id: eventId }, {                                              // 84
        $pull: {                                                                     // 85
          participants: _meteor.Meteor.user().emails[0].address                      // 86
        } });                                                                        //
    }                                                                                //
                                                                                     //
    return cancelParticipation;                                                      //
  }(),                                                                               //
  volunteerUser: function () {                                                       // 89
    function volunteerUser(eventId) {                                                //
      Events.update({ _id: eventId }, {                                              // 90
        $addToSet: {                                                                 // 91
          volunteers: _meteor.Meteor.user().emails[0].address                        // 92
        } });                                                                        //
    }                                                                                //
                                                                                     //
    return volunteerUser;                                                            //
  }(),                                                                               //
  cancelVolunteer: function () {                                                     // 96
    function cancelVolunteer(eventId) {                                              //
      Events.update({ _id: eventId }, {                                              // 97
        $pull: {                                                                     // 98
          volunteers: _meteor.Meteor.user().emails[0].address                        // 99
        } });                                                                        //
    }                                                                                //
                                                                                     //
    return cancelVolunteer;                                                          //
  }(),                                                                               //
  removeEvent: function () {                                                         // 102
    function removeEvent(eventId) {                                                  //
      Events.remove(eventId);                                                        // 103
    }                                                                                //
                                                                                     //
    return removeEvent;                                                              //
  }()                                                                                //
});                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////

}]}},"server":{"main.js":["meteor/meteor","../imports/api/events.js",function(require){

///////////////////////////////////////////////////////////////////////////////////////
//                                                                                   //
// server/main.js                                                                    //
//                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////
                                                                                     //
var _meteor = require('meteor/meteor');                                              // 1
                                                                                     //
require('../imports/api/events.js');                                                 // 3
                                                                                     //
_meteor.Meteor.startup(function () {                                                 // 5
  // code to run on server at startup                                                //
});                                                                                  //
//import all collections from api here                                               //
///////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json",".jsx"]});
require("./server/main.js");
//# sourceMappingURL=app.js.map
